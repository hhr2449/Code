#pragma once
#include <bits/stdc++.h>
using namespace std;
class Fraction {
    public:
        long long up, down;
        Fraction(long long f) {
            this->up = f;
            this->down = 1;
        }
        Fraction() {}
        int gcd(int a, int b){//求解最大公约数
            return b ? gcd(b, a % b) : a;
        }
        Fraction operator+(Fraction f) {
            this->up = this->up*f.down + this->down*f.up;
            this->down = this->down*f.down;
            int g = gcd(this->up, this->down);
            this->up/=g;
            this->down/=g;
            return *this;
        }
        Fraction operator-(Fraction f) {
            this->up = this->up*f.down - this->down*f.up;
            this->down = this->down*f.down;
            int g = gcd(this->up, this->down);
            this->up/=g;
            this->down/=g; 
            return *this;
        }
        Fraction operator*(Fraction f) {
            this->up = this->up*f.up;
            this->down = this->down*f.down;
            int g = gcd(this->up, this->down);
            this->up/=g;
            this->down/=g; 
            return *this;
        }
        Fraction operator/(Fraction f) {
            this->up = this->up*f.down;
            this->down = this->down*f.up;
            int g = gcd(this->up, this->down);
            this->up/=g;
            this->down/=g; 
            return *this;
        }
        Fraction& operator=(Fraction f) {
            this->up = f.up;
            this->down = f.down;
            return *this;
        }
        friend std::ostream& operator<<(std::ostream& out, const Fraction& f) {
            if(f.down == 1) {
                out << f.up << '\n';
                return out;
            }
            out << f.up << '/' << f.down ;
            return out;
        }
};