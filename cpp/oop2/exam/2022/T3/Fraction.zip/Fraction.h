class Fraction {
    
};