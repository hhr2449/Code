#pragma once
#include <bits/stdc++.h>
#define ll long long
using namespace std;
template <class T>
class calculate {
    public:
        T res;
        calculate(char expressionType,ll x,ll y,ll z) {
            if(expressionType == 'A') {
                res = x*x + y*y + z*z;
            }
            else if(expressionType == 'B') {

            }
            else {

            }
        }
        friend std::ostream& operator<<(std::ostream& out, const calculate& cal) {
        out << cal.res;
        return out;
    }
};
