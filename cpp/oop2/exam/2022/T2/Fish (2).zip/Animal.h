#pragma once
#include <bits/stdc++.h>
using namespace std;
class Animal {
    public:
        string color;
        virtual void sing() {

        }
        virtual void swim() {

        }
        Animal() {}
        virtual ~Animal() {}
};