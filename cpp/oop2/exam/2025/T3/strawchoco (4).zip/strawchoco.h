#pragma once
class Strawberry : public EventInterface{
    int mood;
public:
    int flag = 2;
    Strawberry() : mood(0) {}
    ~Strawberry(){}

    int get_mood() {
        return mood;
    }
    void increase_mood(int value) {
        mood += value;
    }

    void zoo(EventInterface* e) {
        increase_mood(1);
        if(e->flag == 1) {
            e->increase_mood(5);
        }
        else {
            e->increase_mood(1);
        }
    }
    void shop(EventInterface* e){
        increase_mood(5);
        if(e->flag == 1) {
            e->increase_mood(1);
        }
        else {
            e->increase_mood(5);
        }
    }
    void birthday(){

    }
};
class Chocolate : public EventInterface{
    int mood;
public:
    int flag = 1;
    Chocolate() : mood(0) {}
    ~Chocolate() {}

    int get_mood() {
        return mood;
    }
    void increase_mood(int value) {
        mood += value;
    }

    void zoo(EventInterface* e) {
        increase_mood(5);
        if(e->flag == 1) {
            e->increase_mood(5);
        }
        else {
            e->increase_mood(1);
        }

    }
    void shop(EventInterface* e) {
        increase_mood(1);
        if(e->flag == 1) {
            e->increase_mood(1);
        }
        else {
            e->increase_mood(5);
        }
    }
    void birthday() {

    }
};