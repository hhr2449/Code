#pragma once
class Strawberry : public EventInterface{
    int mood;
public:
    Strawberry() : mood(0) {}
    ~Strawberry(){}

    int get_mood() {
        return mood;
    }
    void increase_mood(int value) {
        mood += value;
    }

    void zoo(EventInterface*) {
        increase_mood(1);
    }
    void shop(EventInterface*){
        increase_mood(5);
    }
    void birthday(){

    }
};
class Chocolate : public EventInterface{
    int mood;
public:
    Chocolate() : mood(0) {}
    ~Chocolate() {}

    int get_mood() {
        return mood;
    }
    void increase_mood(int value) {
        mood += value;
    }

    virtual void zoo(EventInterface*) {
        increase_mood(5);
    }
    virtual void shop(EventInterface*) {
        increase_mood(1);
    }
    virtual void birthday() {

    }
};