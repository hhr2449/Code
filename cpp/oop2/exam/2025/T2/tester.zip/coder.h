#pragma once 
#include "agent.h"
class Coder : public Agent{
    public:
    int agent_id;
    std::string& codes;
    int sum = 0;
    Coder(int id, std::string& codes): Agent(id, codes), agent_id(id), codes(codes) {}
    void action() {
        string str;
        cin >> str;
        codes += str;
        sum += str.size();
    }
    void report() {
        cout << "Coder " << agent_id <<": " << sum << " characters coded" << '\n';
    }
    ~Coder(){}
};