#include<iostream>
#include"functions.h"
using namespace std;
int main(){
    int a , b;
    cin >> a >> b;
    #ifdef SUM
    cout << custom_sum(a,b) << endl;
    #endif
    #ifdef DEBUG
    cout << custom_sum(a,b) << endl;
    #endif
    #ifdef MINUS
    cout << custom_sum(a,b) << endl;
    cout << custom_minus(a,b) << endl;
    #endif
    #ifdef PRODUCT
    cout << custom_sum(a,b) << endl;
    cout << custom_product(a,b) << endl;
    #endif
    #ifdef DIVIDE
    cout << custom_sum(a,b) << endl;
    cout << custom_divide(a,b) << endl;
    #endif

}