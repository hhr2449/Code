#include "ChatUser.h"

    void ChatUser:: addFriend(ChatUser* user){
        if(user == nullptr){
            return;
        }
        bool isFriend = false;
        for(int i=0;i<this->friends.size();i++){
            if(this->friends[i]->name==user->name){
                isFriend = true;
            }
        }
        if(isFriend){
            std::cout << this->name << " and " << user->name << " are already friends" << '\n';
            return;
        }
        else{
            friends.push_back(user);
            std::cout << this->name <<" -> add friend -> " << user -> name << '\n';
        }
    }
    void ChatUser:: removeFriend(ChatUser* user){
        if(user == nullptr){
            return;
        }
        bool isFriend = false;
        for(int i=0;i<this->friends.size();i++){
            if(this->friends[i]->name==user->name){
                isFriend = true;
                break;
            }
        }
        if(!isFriend){
            std::cout << this->name << " and " << user->name << " are not yet friends" <<'\n';
        }
        else{
            for(int i = 0;i < this->friends.size();i++){
                if(user->name == this->friends[i]->name){
                    std::cout << this->name << " -> remove friend -> " << user->name << '\n';
                    for(int j = i;j < this->friends.size()-1;j++){
                        this->friends[j] = this->friends[j+1];
                    }
                }
            }
        }
    }
    void ChatUser:: sendMessage(ChatUser* user, std::string message){
        if(user == nullptr){
            return;
        }
        std::cout << this->name << " -> send message -> " << user->name << " : " << message << '\n';
        user->receiveMessage(this, message);
    }
    void ChatUser:: receiveMessage(ChatUser* user, std::string message){
        if(user == nullptr){
            return;
        }
        std::cout << this->name << " -> receive message -> " << user->name << " : " << message << '\n';
        bool isFind = false;
        for(int i = 0;i < this->messageQueue.size();i++){
            if(this->messageQueue[i].first->name == user->name){
                this->messageQueue[i].second.push_back(message);
                isFind = true;
            }
           
        }
        if(!isFind){
            std::pair<ChatUser*, std::vector<std::string>> temp;
            temp.first = user;
            temp.second.push_back(message);
            this->messageQueue.push_back(temp);
        }
    }
    void ChatUser:: showMessage(){
        std::cout << "Chat " << this->name << ":" << '\n';
        for(int i=0;i<this->messageQueue.size();i++){
            std::cout << ">> From " << this->messageQueue[i].first->name << ":" << '\n';
            for(int j = 0;j<this->messageQueue[i].second.size();j++){
                std::cout << ">> " << this->messageQueue[i].second[j] << '\n';
            }
        }
    }
    void ChatUser:: showFriends(){
        std::cout << this->name << "'s friend: ";
        for(int i = 0;i<this->friends.size();i++){
            std::cout << this->friends[i]->name << ' ';
        }
        std::cout << '\n';
    }

