#pragma once
#include "card.h"
#include <vector>
#include <list>
#include <iostream>
using namespace std;
class Cards {
	list<Card> l;
public:
	Cards() {		
	}
	Cards(std::string n, std::vector<int> v) {
		for(int i = 0; i < v.size(); i++) {
			l.push_back(Card(n, v[i]));
		}

	}
	void put(Card c) {
		l.push_back(c);
	}
	void print() {
		if(this->l.size() == 0) {
			cout << "empty" << endl;
			return;
		}
		for (list<Card>::iterator it = this->l.begin(); it != this->l.end(); it++) {
			cout << *it << ' ';
		}
		cout << endl;
	}
	int count() {
		return this->l.size();
	}
	void merge(Cards & c) {
		auto& a = this->l.back();
		auto& b = v.l.front();
		a.number = a.number^b.number;
		this->l.splice(--this->l.end(), c.l);
	}
};