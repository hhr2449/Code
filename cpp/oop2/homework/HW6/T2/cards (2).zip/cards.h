#pragma once
#include "card.h"
#include <vector>
#include <list>
#include <iostream>
using namespace std;
class Cards {
	list<Card> l;
public:
	Cards() {		
	}
	Cards(std::string n, std::vector<int> v) {
		for(int i = 0; i < v.size(); i++) {
			l.push_back(Card(n, v[i]));
		}

	}
	void put(Card c) {
		l.push_back(c);
	}
	void print() {
		if(this->l.size() == 0) {
			cout << "empty" << endl;
			return;
		}
		for (list<Card>::iterator it = this->l.begin(); it != this->l.end(); it++) {
			cout << *it << ' ';
		}
		cout << endl;
	}
	int count() {
		return this->l.size();
	}
	void merge(Cards & c) {
		auto& lastThis = this->l.back();      // 获取最后一个元素
    auto& firstOther = c.l.front();       // 获取对方第一个元素

    // 3. 显式运算
    int xorResult = lastThis.number ^ firstOther.number;
    
    // 4. 修改属性
    lastThis.number = xorResult;

    // 5. 合并列表（移动语义优化）
    this->l.splice(this->l.end(), std::move(c.l));
	}
};