#pragma once
class Part{
    public:
    int id;
    Part(int id_):id(id_){}
};