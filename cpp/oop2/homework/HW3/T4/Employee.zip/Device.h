#include"_Device.h"
class BaseLock : public Device {
    public:
    bool isUnlocked(const std::vector<Device*>& accessed) override;
    void execute() override;
    std::string getName() const override;
    Department getAllowedDepartment() const override;
};
class SecurityPanel : public Device {
    public:
    bool isUnlocked(const std::vector<Device*>& accessed) override;
    void execute() override;
    std::string getName() const override;
    Department getAllowedDepartment() const override;
};
class DataTerminal : public Device {
    public:
    int capacity;
    DataTerminal(int capa);
    bool isUnlocked(const std::vector<Device*>& accessed) override;
    void execute() override;
    std::string getName() const override;
    Department getAllowedDepartment() const override;
};
class OpticalTool : public Device {
    public:
    bool isUnlocked(const std::vector<Device*>& accessed) override;
    void execute() override;
    std::string getName() const override;
    Department getAllowedDepartment() const override;
};


//注意派生类中重写的函数也要在类声明中声明