#include"ninja.h"
class FireNinja : public Ninja {
    public:
    FireNinja(string dragon_, string weapon_);
    void describe();
    void fire_power();
};