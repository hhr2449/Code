#include "Map.h"
    Map::Map(int n) {
        data = new Pair[n+1];
    }
    int Map::search(string target) {
        int sizePair = num;
        for(int i = 1; i <= sizePair; ++i){
            if(data[i].hasKey(target)) {
                return i;
            }
        }
        return 0;
    }
    
    int Map::search(string target) const {
        int sizePair = num;
        for(int i = 1; i <= sizePair; ++i){
            if(data[i].hasKey(target)) {
                return i;
            }
        }
        return 0;
    }
    int& Map::operator[] (string key_) {
        int a = search(key_);
        if(a) {
            return data[a].getVal();
        }
        else {
            data[++num].reset(key_,0);
            return data[num].getVal();
        }
    }
    int Map::operator[] (string key_) const {
        int a = search(key_);
        if(a) {
            return data[a].getVal();
        }
        else {
            return 0;
        }
    }
    int Map::size () {
        return num - 1;
    }
    Map::~Map() {
        if(data != nullptr){
            delete [] data;
        }
    }